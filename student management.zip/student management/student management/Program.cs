﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace student_management
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, n;
            Console.WriteLine("Enter num of records = ");
            n = int.Parse(Console.ReadLine());

            student[] ob = new student[n];
            for (i = 0; i < n; i++)
            {
                ob[i] = new student();
                ob[i].getdata();
            }
            for (i = 0; i < n; i++)
            {
                ob[i].display();
            }
        }
    }
}
